const mongoose = require('mongoose');

const transaksiDariSupplierSchema = new mongoose.Schema({
  produk: { type: mongoose.Schema.Types.ObjectId, ref: 'Produk' },
  supplier: { type: mongoose.Schema.Types.ObjectId, ref: 'Supplier' },
  jumlah: { type: Number, required: true },
  tanggal: { type: Date, required: true }
});

module.exports = mongoose.model('TransaksiDariSupplier', transaksiDariSupplierSchema);
