const mongoose = require('mongoose');

const supplierSchema = new mongoose.Schema({
  nama: { type: String, required: true },
  alamat: { type: String, required: true }
});

module.exports = mongoose.model('Supplier', supplierSchema);
