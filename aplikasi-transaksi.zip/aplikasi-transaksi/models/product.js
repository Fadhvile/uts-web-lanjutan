const mongoose = require('mongoose');

const produkSchema = new mongoose.Schema({
  nama: { type: String, required: true },
  jumlahStok: { type: Number, required: true },
  kategori: { type: mongoose.Schema.Types.ObjectId, ref: 'Kategori' }
});

module.exports = mongoose.model('Produk', produkSchema);
