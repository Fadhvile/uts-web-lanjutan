const mongoose = require('mongoose');

const transaksiKeCustomerSchema = new mongoose.Schema({
  produk: { type: mongoose.Schema.Types.ObjectId, ref: 'Produk' },
  jumlah: { type: Number, required: true },
  tanggal: { type: Date, required: true }
});

module.exports = mongoose.model('TransaksiKeCustomer', transaksiKeCustomerSchema);
