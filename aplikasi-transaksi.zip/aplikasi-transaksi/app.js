const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const kategoriRoutes = require('./routes/kategoriRoutes');
const produkRoutes = require('./routes/produkRoutes');
const supplierRoutes = require('./routes/supplierRoutes');
const transaksiRoutes = require('./routes/transaksiRoutes');

// Inisialisasi Express
const app = express();

// Middleware
app.use(bodyParser.json());

// Koneksi ke Database
mongoose.connect('mongodb://localhost:27017/aplikasiTransaksi', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log("Database berhasil terhubung.");
}).catch((err) => {
  console.error("Koneksi database gagal:", err);
});

// Menggunakan Routes
app.use('/kategori', kategoriRoutes);
app.use('/produk', produkRoutes);
app.use('/supplier', supplierRoutes);
app.use('/transaksi', transaksiRoutes);

// Server
const port = 3000;
app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});
