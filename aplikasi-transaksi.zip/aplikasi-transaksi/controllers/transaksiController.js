const TransaksiDariSupplier = require('../models/transaksiDariSupplier');
const TransaksiKeCustomer = require('../models/transaksiKeCustomer');

// Membuat transaksi dari supplier
exports.createTransaksiDariSupplier = async (req, res) => {
  try {
    const transaksi = new TransaksiDariSupplier({
      produk: req.body.produk,
      supplier: req.body.supplier,
      jumlah: req.body.jumlah,
      tanggal: req.body.tanggal
    });
    await transaksi.save();
    res.status(201).send(transaksi);
  } catch (error) {
    res.status(400).send(error);
  }
};

// Membuat transaksi ke customer
exports.createTransaksiKeCustomer = async (req, res) => {
  try {
    const transaksi = new TransaksiKeCustomer({
      produk: req.body.produk,
      jumlah: req.body.jumlah,
      tanggal: req.body.tanggal
    });
    await transaksi.save();
    res.status(201).send(transaksi);
  } catch (error) {
    res.status(400).send(error);
  }
};
