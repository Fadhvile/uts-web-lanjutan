const Supplier = require('../models/supplier');

// Membuat supplier baru
exports.createSupplier = async (req, res) => {
  try {
    const supplier = new Supplier({
      nama: req.body.nama,
      alamat: req.body.alamat
    });
    await supplier.save();
    res.status(201).send(supplier);
  } catch (error) {
    res.status(400).send(error);
  }
};

// Mendapatkan semua supplier
exports.getSupplier = async (req, res) => {
  try {
    const suppliers = await Supplier.find();
    res.status(200).send(suppliers);
  } catch (error) {
    res.status(400).send(error);
  }
};

// Memperbarui supplier
exports.updateSupplier = async (req, res) => {
  try {
    const supplier = await Supplier.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.status(200).send(supplier);
  } catch (error) {
    res.status(400).send(error);
  }
};

// Menghapus supplier
exports.deleteSupplier = async (req, res) => {
  try {
    await Supplier.findByIdAndDelete(req.params.id);
    res.status(200).send({ message: 'Supplier dihapus' });
  } catch (error) {
    res.status(400).send(error);
  }
};
