const Kategori = require('../models/kategori');

// Membuat kategori baru
exports.createKategori = async (req, res) => {
  try {
    const kategori = new Kategori({ nama: req.body.nama });
    await kategori.save();
    res.status(201).send(kategori);
  } catch (error) {
    res.status(400).send(error);
  }
};

// Mendapatkan semua kategori
exports.getKategori = async (req, res) => {
  try {
    const kategoris = await Kategori.find();
    res.status(200).send(kategoris);
  } catch (error) {
    res.status(400).send(error);
  }
};

// Memperbarui kategori
exports.updateKategori = async (req, res) => {
  try {
    const kategori = await Kategori.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.status(200).send(kategori);
  } catch (error) {
    res.status(400).send(error);
  }
};

// Menghapus kategori
exports.deleteKategori = async (req, res) => {
  try {
    await Kategori.findByIdAndDelete(req.params.id);
    res.status(200).send({ message: 'Kategori dihapus' });
  } catch (error) {
    res.status(400).send(error);
  }
};
