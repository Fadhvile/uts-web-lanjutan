const Produk = require('../models/produk');

// Membuat produk baru
exports.createProduk = async (req, res) => {
  try {
    const produk = new Produk({
      nama: req.body.nama,
      jumlahStok: req.body.jumlahStok,
      kategori: req.body.kategori
    });
    await produk.save();
    res.status(201).send(produk);
  } catch (error) {
    res.status(400).send(error);
  }
};

// Mendapatkan semua produk
exports.getProduk = async (req, res) => {
  try {
    const produks = await Produk.find().populate('kategori');
    res.status(200).send(produks);
  } catch (error) {
    res.status(400).send(error);
  }
};

// Memperbarui produk
exports.updateProduk = async (req, res) => {
  try {
    const produk = await Produk.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.status(200).send(produk);
  } catch (error) {
    res.status(400).send(error);
  }
};

// Menghapus produk
exports.deleteProduk = async (req, res) => {
  try {
    await Produk.findByIdAndDelete(req.params.id);
    res.status(200).send({ message: 'Produk dihapus' });
  } catch (error) {
    res.status(400).send(error);
  }
};
