const request = require('supertest');
const app = require('../app'); // Import the Express app

// Global variables
let kategoriId, produkId, supplierId, transaksiSupplierId, transaksiCustomerId;

// Test kategori (category) routes
describe('Kategori Routes', () => {
  it('should create a new kategori', async () => {
    const response = await request(app)
      .post('/kategori')
      .send({ nama: 'Elektronik' })
      .expect(201);
    
    kategoriId = response.body._id;
    expect(response.body.nama).toBe('Elektronik');
  });

  it('should get all kategoris', async () => {
    const response = await request(app)
      .get('/kategori')
      .expect(200);
    
    expect(response.body.length).toBeGreaterThan(0);
  });

  it('should update kategori', async () => {
    const response = await request(app)
      .put(`/kategori/${kategoriId}`)
      .send({ nama: 'Peralatan Rumah Tangga' })
      .expect(200);
    
    expect(response.body.nama).toBe('Peralatan Rumah Tangga');
  });

  it('should delete kategori', async () => {
    await request(app)
      .delete(`/kategori/${kategoriId}`)
      .expect(200);
    
    const response = await request(app)
      .get('/kategori')
      .expect(200);
    
    expect(response.body.some(k => k._id === kategoriId)).toBeFalsy();
  });
});

// Test produk (product) routes
describe('Produk Routes', () => {
  it('should create a new produk', async () => {
    const response = await request(app)
      .post('/produk')
      .send({
        nama: 'Smartphone',
        jumlahStok: 50,
        kategori: kategoriId
      })
      .expect(201);
    
    produkId = response.body._id;
    expect(response.body.nama).toBe('Smartphone');
    expect(response.body.jumlahStok).toBe(50);
  });

  it('should get all produks', async () => {
    const response = await request(app)
      .get('/produk')
      .expect(200);
    
    expect(response.body.length).toBeGreaterThan(0);
  });

  it('should update produk', async () => {
    const response = await request(app)
      .put(`/produk/${produkId}`)
      .send({ jumlahStok: 100 })
      .expect(200);
    
    expect(response.body.jumlahStok).toBe(100);
  });

  it('should delete produk', async () => {
    await request(app)
      .delete(`/produk/${produkId}`)
      .expect(200);
    
    const response = await request(app)
      .get('/produk')
      .expect(200);
    
    expect(response.body.some(p => p._id === produkId)).toBeFalsy();
  });
});

// Test supplier routes
describe('Supplier Routes', () => {
  it('should create a new supplier', async () => {
    const response = await request(app)
      .post('/supplier')
      .send({ nama: 'Supplier A', alamat: 'Jakarta' })
      .expect(201);
    
    supplierId = response.body._id;
    expect(response.body.nama).toBe('Supplier A');
    expect(response.body.alamat).toBe('Jakarta');
  });

  it('should get all suppliers', async () => {
    const response = await request(app)
      .get('/supplier')
      .expect(200);
    
    expect(response.body.length).toBeGreaterThan(0);
  });

  it('should update supplier', async () => {
    const response = await request(app)
      .put(`/supplier/${supplierId}`)
      .send({ alamat: 'Surabaya' })
      .expect(200);
    
    expect(response.body.alamat).toBe('Surabaya');
  });

  it('should delete supplier', async () => {
    await request(app)
      .delete(`/supplier/${supplierId}`)
      .expect(200);
    
    const response = await request(app)
      .get('/supplier')
      .expect(200);
    
    expect(response.body.some(s => s._id === supplierId)).toBeFalsy();
  });
});

// Test transaksi (transaction) routes
describe('Transaksi Routes', () => {
  it('should create transaksi dari supplier', async () => {
    const response = await request(app)
      .post('/transaksi/dari-supplier')
      .send({
        produk: produkId,
        supplier: supplierId,
        jumlah: 30,
        tanggal: new Date()
      })
      .expect(201);
    
    transaksiSupplierId = response.body._id;
    expect(response.body.jumlah).toBe(30);
  });

  it('should create transaksi ke customer', async () => {
    const response = await request(app)
      .post('/transaksi/ke-customer')
      .send({
        produk: produkId,
        jumlah: 10,
        tanggal: new Date()
      })
      .expect(201);
    
    transaksiCustomerId = response.body._id;
    expect(response.body.jumlah).toBe(10);
  });
});
