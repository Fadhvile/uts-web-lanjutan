const express = require('express');
const router = express.Router();
const kategoriController = require('../controllers/kategoriController');

router.post('/', kategoriController.createKategori);
router.get('/', kategoriController.getKategori);
router.put('/:id', kategoriController.updateKategori);
router.delete('/:id', kategoriController.deleteKategori);

module.exports = router;
