const express = require('express');
const router = express.Router();
const supplierController = require('../controllers/supplierController');

// Add routes here using supplierController

module.exports = router;
