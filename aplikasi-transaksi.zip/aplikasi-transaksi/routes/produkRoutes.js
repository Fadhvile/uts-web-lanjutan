const express = require('express');
const router = express.Router();
const produkController = require('../controllers/produkController');

// Add routes here using produkController

module.exports = router;
