const express = require('express');
const router = express.Router();
const transaksiController = require('../controllers/transaksiController');

// Menambahkan transaksi dari supplier
router.post('/dari-supplier', transaksiController.createTransaksiDariSupplier);

// Menambahkan transaksi ke customer
router.post('/ke-customer', transaksiController.createTransaksiKeCustomer);

module.exports = router;
